// Professional anatomy figures from OpenStax Anatomy and Physiology 2e (Betts et al., OpenStax, Rice University),
// licensed CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Resized; unchanged otherwise.
// PHOTOS replaces a drawn diagram (same key) wherever it is used. SYS_PHOTOS adds extra figures to a system's Diagrams tab.
// Labels in the figures use US spelling (esophagus, hemorrhage) and US units where noted.
window.OX_CREDIT='OpenStax Anatomy & Physiology 2e, CC BY 4.0';
window.PHOTOS={
 heart:{f:'2008_internal_anatomy_of_the_heartn',cap:'Inside the heart: chambers, valves and great vessels (front view)'},
 circulation:{f:'2003_dual_system_of_human_circulation',cap:'Double circulation: the lungs (pulmonary) and the body (systemic)'},
 airway:{f:'2301_major_respiratory_organs',cap:'The respiratory system: nose and mouth to the lungs'},
 alveolus:{f:'2309_the_respiratory_zone',cap:'Alveoli: where oxygen enters the blood'},
 brain:{f:'1306_lobes_of_cerebral_cortexn',cap:'Lobes of the brain (left side view)',note:'Frontal: personality, behaviour, movement. Parietal: touch and position. Temporal: hearing, memory, speech understanding. Occipital: vision.'},
 cns:{f:'1201_overview_of_nervous_system',cap:'Central nervous system (brain and spinal cord) and peripheral nerves'},
 gi:{f:'2401_components_of_the_digestive_system',cap:'The digestive system'},
 quadrants:{f:'111_abdominal_quadrant_regions',cap:'Abdominal regions (a) and quadrants (b)',note:'RUQ: liver, gallbladder. LUQ: stomach, spleen. RLQ: appendix, right ovary. LLQ: sigmoid colon, left ovary. Remember the patient’s right is on your left.'},
 urinary:{f:'2608_kidney_position_in_abdomen',cap:'The kidneys sit high at the back, under the lower ribs'},
 skeleton:{f:'801_appendicular_skeleton',cap:'The skeleton: front and back views'},
 skeleton2:{f:'701_axial_skeleton_01',cap:'The skeleton: skull, spine and ribs (axial) and limbs (appendicular)'},
 endocrine:{f:'1801_the_endocrine_system',cap:'The endocrine glands'},
 glucose:{f:'1822_the_homostatic_regulation_of_blood_glucose_levels',cap:'How insulin and glucagon keep blood glucose in range',note:'This figure uses US units: 70 to 110 mg/dL is about 4 to 6 mmol/L. Below 4 mmol/L is a hypo.'},
 lymph:{f:'2201_anatomy_of_the_lymphatic_system',cap:'The lymphatic system and immune organs'},
 skin:{f:'501_structure_of_the_skin',cap:'Layers of the skin: epidermis, dermis and fat (hypodermis)',note:'Superficial burns affect the epidermis only. Partial thickness burns reach into the dermis and blister. Full thickness burns go through the dermis: white or charred, often painless.'},
 nines:{f:'513_degree_of_burns',cap:'Rule of nines: estimating burn area in adults',note:'The patient’s palm and fingers are about 1% of their body surface: useful for small or patchy burns. Children have a larger head and smaller legs.'},
 repro:{f:'figure_28_02_06',cap:'Female reproductive organs: uterus, tubes and ovaries (front view)'},
 eye:{f:'1413_structure_of_the_eye',cap:'Structure of the eye (cross-section)'},
 blood:{f:'1901_composition_of_blood',cap:'What blood is made of: plasma, white cells and platelets, red cells'},
 feedback:{f:'105_negative_feedback_loops',cap:'Negative feedback: how the body corrects body temperature'},
 longbone:{f:'603_anatomy_of_a_long_bone',cap:'Inside a long bone such as the femur'},
 synovial:{f:'907_synovial_joints',cap:'A synovial joint'},
 territories:{f:'2123_arteries_of_the_brain',cap:'Arteries of the brain (seen from below)',note:'Middle cerebral artery strokes are the most common: face and arm weakness on the opposite side, and speech problems if on the left.'},
 cranial:{f:'1320_the_cranial_nerves',cap:'The 12 cranial nerves (brain seen from below)'},
 dermatomes:{f:'1611_dermatomes_02',cap:'Dermatomes: which spinal nerve supplies each area of skin',note:'Landmarks: C6 thumb, C7 middle finger, C8 little finger, T4 nipple line, T10 belly button, L4 inner ankle, S1 little toe and outer foot.'},
 arteries:{f:'2120_major_systemic_artery',cap:'Major arteries of the body',note:'Pulse points: carotid (neck), brachial (inner elbow), radial (wrist), femoral (groin), popliteal (behind the knee), posterior tibial (inner ankle), dorsalis pedis (top of the foot).'},
 veins:{f:'2131_major_systematic_veins',cap:'Major veins of the body'}
};
window.SYS_PHOTOS={
 cardiovascular:[{f:'2001_heart_position_in_thoraxn',cap:'Where the heart sits in the chest'},{f:'2014ab_coronary_blood_vessels',cap:'Coronary arteries: the heart’s own blood supply'},{f:'2113ab_atherosclerosis',cap:'Atherosclerosis: fatty plaque narrowing an artery (the cause of angina and heart attacks)'}],
 respiratory:[{f:'2312_gross_anatomy_of_the_lungs',cap:'The lungs: three lobes on the right, two on the left'},{f:'2306_the_larynx',cap:'The larynx (voice box) and epiglottis'},{f:'2311_lung_tissue',cap:'Airway wall: normal (a) and during an asthma attack (b), swollen, tight and full of mucus'}],
 nervous:[{f:'1311_brain_stem',cap:'The brain stem: midbrain, pons and medulla (breathing and heart control)'},{f:'1602_the_hemorrhagic_stroke_02',cap:'Haemorrhagic stroke: bleeding into the brain, (a) drawing and (b) CT scan'},{f:'1313_spinal_cord_cross_section',cap:'Spinal cord cross-section'}],
 musculoskeletal:[{f:'612_types_of_fractures',cap:'Types of fracture: closed, open, transverse, spiral, comminuted, impacted, greenstick, oblique'},{f:'917_knee_joint',cap:'The knee joint: ligaments and menisci'}],
 urinary:[{f:'2610_the_kidney',cap:'Inside the kidney'},{f:'2605_the_bladder',cap:'The bladder'}],
 sensory:[{f:'1508_autonomic_control_of_pupil_size',cap:'How the pupils react to light'}]
};
