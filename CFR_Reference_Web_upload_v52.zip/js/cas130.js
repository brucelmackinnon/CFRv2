// CAS130 Responder Skills / Equipment Record: the paper form as a screen, filled in from the patient record.
// Everything lives in App.patient.cas (memory only, cleared with the patient). Only the responder's own
// call sign and PIN can be remembered on the phone, and only if they choose to.
(function(){
const {esc,callout,route}=App;
const RESP='cfr.responder';
const responder=()=>App.LS.get(RESP,{});
const hhmm=t=>t?App.time(t):'';
const YN=[['Yes','Yes'],['No','No']];

/* --- helpers reading the record --- */
const obs=p=>p.obs||[];
const last=p=>{const o=obs(p);return o[o.length-1];};
const lastWith=(p,f)=>{const o=obs(p);for(let i=o.length-1;i>=0;i--)if(f(o[i]))return o[i];return null;};
const latestVal=(p,k)=>{const o=lastWith(p,x=>x[k]!=null&&x[k]!=='');return o?o[k]:undefined;};
const arrest=()=>(App.arrestState?App.arrestState():null)||{log:[]};
const evt=re=>{const a=arrest();return (a.log||[]).filter(l=>re.test(l.e));};
const allergyAuto=p=>{const v=latestVal(p,'allergy');if(v)return v;const t=(p.sample.allergies||'').trim();if(!t)return undefined;return /^(none|nil|no|nka|nkda|no known.*)$/i.test(t)?'No':'Yes';};
const ageNum=p=>{const m=String(p.info.age||'').match(/\d+/);return m?+m[0]:null;};

/* --- the form. [key,label,type,options|null,auto(p)] --- */
const F=[
 ['Incident',[
  ['incDate','Incident date','text',null,()=>new Date().toLocaleDateString('en-GB')],
  ['incNo','Incident number','text'],
  ['callsign','Responder call sign','text',null,()=>responder().callsign],
  ['pin1','Responder PIN (1)','text',null,()=>responder().pin],
  ['pin2','Responder PIN (2)','text'],
  ['callTime','Call time','time'],
  ['mobileTime','Mobile time','time'],
  ['atScene','At scene','time',null,p=>hhmm(p.started)]]],
 ['Basic observations',[
  ['response','Response (AVPU)','pick',[['A','A: Alert'],['C','C: New confusion'],['V','V: Voice'],['P','P: Pain'],['U','U: Unresponsive']],p=>latestVal(p,'acvpu')],
  ['airway','Airway','pick',[['1','1: Clear'],['2','2: Partly obstructed'],['3','3: Obstructed'],['4','4: Vomited']]],
  ['breathing','Breathing','pick',[['Normal','Normal'],['SOB','SOB / unable to speak full sentences'],['Abnormal','Abnormal / absent (CPR)']]],
  ['bloodLoss','External blood loss','yn',YN],
  ['bpSys','BP systolic','num',null,p=>latestVal(p,'sbp')],
  ['bpDia','BP diastolic','num',null,p=>latestVal(p,'dbp')],
  ['hr','Heart rate','num',null,p=>latestVal(p,'hr')],
  ['pulseRhythm','Pulse rhythm','pick',[['Regular','Regular'],['Irregular','Irregular']],p=>{const v=latestVal(p,'rhythm');return v?(/irreg/.test(v)?'Irregular':'Regular'):undefined;}],
  ['pulseVol','Pulse strength','pick',[['Strong','Strong'],['Weak','Weak']],p=>{const v=latestVal(p,'vol');return v?(v==='strong'?'Strong':'Weak'):undefined;}],
  ['rr','Breathing rate','num',null,p=>latestVal(p,'rr')],
  ['temp','Temperature °C','num',null,p=>latestVal(p,'temp')],
  ['pain','Pain score /10','num',null,p=>latestVal(p,'pain')],
  ['entonox','Entonox administered','yn',YN],
  ['obsTime','Time of observations','time',null,p=>last(p)?hhmm(last(p).t):''],
  ['duration','Duration of symptoms','text',null,p=>p.info.duration],
  ['durUnit','Hours or days','pick',[['Hours','Hours'],['Days','Days']]]]],
 ['Resuscitation',[
  ['bls','BLS given','yn',YN,()=>arrest().start?'Yes':undefined],
  ['aed','AED used','yn',YN,()=>evt(/AED attached|Shock/).length?'Yes':undefined],
  ['pads','AED pads','pick',[['Adult','Adult pads'],['Paed','Paed pads (under 8)']]],
  ['padsTime','Time AED pads applied','time',null,()=>{const e=evt(/AED attached/)[0];return e?hhmm(e.t):'';}],
  ['shocks','Shocks given','num',null,()=>{const a=arrest();return a.start?evt(/Shock delivered/).length:undefined;}],
  ['breathReturn','Did breathing return','yn',YN,()=>evt(/ROSC/).length?'Yes':undefined],
  ['breathTime','Time breathing returned','time',null,()=>{const e=evt(/ROSC/)[0];return e?hhmm(e.t):'';}]]],
 ['Aspirin (cardiac-sounding chest pain)',[
  ['aAllergy','Known allergy or hypersensitivity','yn',YN,allergyAuto],
  ['aUnder16','Under 16 years of age','yn',YN,p=>{const a=ageNum(p);return a==null?undefined:a<16?'Yes':'No';}],
  ['aGI','Current active GI bleeding','yn',YN],
  ['aHaem','Haemophilia or other clotting disorder','yn',YN],
  ['aLiver','Severe liver disease','yn',YN],
  ['aTaken','300 mg already taken since the 999 call','yn',YN],
  ['aspirin','300 mg aspirin given','yn',YN],
  ['aspirinTime','Time aspirin given','time']]],
 ['Oxygen',[
  ['spo2Air','SpO₂ without O₂ %','num',null,p=>{const o=lastWith(p,x=>x.spo2!=null&&x.o2!==true);return o?o.spo2:undefined;}],
  ['spo2O2','SpO₂ with O₂ %','num',null,p=>{const o=lastWith(p,x=>x.spo2!=null&&x.o2===true);return o?o.spo2:undefined;}],
  ['o2Given','Oxygen administered','yn',YN,p=>obs(p).some(x=>x.o2===true)?'Yes':obs(p).some(x=>x.o2===false)?'No':undefined]]],
 ['Stroke',[
  ['fast','FAST performed','yn',YN,p=>latestVal(p,'fast')],
  ['face','Face: paralysis','yn',YN],
  ['armR','Arm: right weakness','yn',YN],
  ['armL','Arm: left weakness','yn',YN],
  ['speech','Speech: slurred','yn',YN],
  ['strokeOnset','Time onset of symptoms','time',null,p=>/^\d{1,2}:\d{2}$/.test(p.info.onset||'')?p.info.onset:'']]],
 ['Diabetic',[
  ['bm','BM/CBG mmol/L','num',null,p=>latestVal(p,'bm')],
  ['sugarGiven','High sugar food / drink given','yn',YN],
  ['glucogel','Glucogel administered','yn',YN],
  ['glucoDose','Estimated dose (grams)','num']]],
 ['Responder actions',[
  ['pocketMask','Pocket mask used','yn',YN],
  ['bvm','Bag valve mask used','yn',YN],
  ['suction','Suction used','yn',YN],
  ['opa','OP airway used','yn',YN],
  ['opaSize','OP airway size','text'],
  ['recovery','Recovery position','yn',YN],
  ['wound','Wound dressed and elevated for serious blood loss','yn',YN]]],
 ['History',[
  ['allergies','Allergies','yn',YN,allergyAuto],
  ['allergyDetail','Allergic to','text',null,p=>{const t=(p.sample.allergies||'').trim();if(t&&allergyAuto(p)==='Yes')return t;return latestVal(p,'allergyTo');}],
  ['meds','Currently takes medication','yn',YN,p=>p.meds.length?'Yes':undefined],
  ['medList','Medicines','text',null,p=>p.meds.join(', ')],
  ['complaint','Presenting complaint / previous medical history','area',null,p=>[p.info.complaint,p.sample.signs&&('Signs: '+p.sample.signs),p.sample.past&&('PMH: '+p.sample.past),p.sample.events&&('Events: '+p.sample.events)].filter(Boolean).join('\n')]]],
 ['Safeguarding',[
  ['safeguard','Safeguarding child / adult issue','yn',YN],
  ['informed','If yes, informed attending clinician','yn',YN]]]
];
const FLAT={};F.forEach(([,fs])=>fs.forEach(f=>FLAT[f[0]]=f));

function val(p,k){const c=p.cas||{};if(k in c)return {v:c[k],auto:false};const f=FLAT[k];const a=f[4]?f[4](p):undefined;return {v:a==null||a===''?'':a,auto:a!=null&&a!==''};}
const show=(k,v)=>{const f=FLAT[k];if(f[3]&&v!==''){const o=f[3].find(x=>String(x[0])===String(v));if(o)return o[1];}return String(v);};

function fieldHTML(p,f){const [k,l,type,opts]=f;const {v,auto}=val(p,k);
  const tag=auto?'<em class="autotag">auto</em>':'';
  if(type==='yn'||type==='pick')return `<div class="casf" data-cf="${k}"><p class="small muted casl">${esc(l)} ${tag}</p><div class="picker${type==='pick'&&opts.length>3?' wrap':''}">${opts.map(([ov,ol])=>`<button type="button" data-cv="${esc(ov)}" aria-pressed="${String(v)===String(ov)}">${esc(ol)}</button>`).join('')}</div></div>`;
  if(type==='area')return `<label class="fld casf" data-cf="${k}"><span>${esc(l)} ${tag}</span><textarea data-ci="${k}" rows="4">${esc(v)}</textarea></label>`;
  return `<label class="fld casf" data-cf="${k}"><span>${esc(l)} ${tag}</span><input data-ci="${k}" ${type==='num'?'inputmode="decimal"':''} type="${type==='time'?'time':'text'}" value="${esc(v)}"></label>`;}

App.casText=(withBlanks)=>{const p=App.patient;if(!p)return '';const L=['CAS130 RESPONDER SKILLS / EQUIPMENT RECORD',App.dateTime()];
  const n=last(p)?Tools.news2(last(p)):null;
  F.forEach(([sec,fs])=>{const rows=[];fs.forEach(f=>{const {v}=val(p,f[0]);if(v===''&&!withBlanks)return;rows.push(`${f[1]}: ${v===''?'—':show(f[0],v)}`);});
    if(sec==='Basic observations'&&n&&n.missing.length<7)rows.push(`NEWS2: ${n.total} (${App.newsRisk(last(p))})${n.complete?'':' incomplete'}`);
    if(rows.length){L.push('');L.push(sec.toUpperCase());rows.forEach(r=>L.push(r));}});
  if(obs(p).length>1){L.push('');L.push('OBS SETS');obs(p).forEach(o=>L.push(`${App.time(o.t)} ${App.obsSummary(o)} · NEWS2 ${Tools.news2(o).total}`));}
  return L.join('\n');};


/* ---------- paper-style form picture (canvas) ---------- */
const FONT='Helvetica, Arial, sans-serif',INK='#111',PEN='#0B2E8A',W=1240,M=36;
function wrap(ctx,t,w){const out=[];String(t).split('\n').forEach(par=>{let line='';par.split(/\s+/).forEach(word=>{const tryL=line?line+' '+word:word;if(ctx.measureText(tryL).width>w&&line){out.push(line);line=word;}else line=tryL;});out.push(line);});return out;}
function drawItem(ctx,p,f,x,y,w,dry){const [k,l,type,opts]=f;const v=f.blank?'':val(p,k).v;
  ctx.font=`19px ${FONT}`;ctx.fillStyle=INK;ctx.textBaseline='middle';
  if(type==='yn'||type==='pick'){
    const ow=opts.map(([,ol])=>{ctx.font=`18px ${FONT}`;return 30+ctx.measureText(type==='pick'?ol:ol).width+18;});
    const total=ow.reduce((a,b)=>a+b,0);ctx.font=`19px ${FONT}`;
    const lab=wrap(ctx,l,Math.max(140,w-total-12));const oneLine=lab.length===1&&ctx.measureText(l).width+total+16<=w;
    let h;let ox,oy;
    if(oneLine){h=38;ox=x+w-total;oy=y+19;if(!dry)ctx.fillText(l,x,oy);}
    else{const ll=wrap(ctx,l,w);if(!dry)ll.forEach((t,i)=>ctx.fillText(t,x,y+16+i*24));oy=y+16+ll.length*24+6;ox=x+12;h=oy-y+22;}
    let cx=ox,cy=oy;opts.forEach(([ov,ol],i)=>{if(cx+ow[i]>x+w+4&&cx>x+12){cx=x+12;cy+=34;h+=34;}
      if(!dry){ctx.beginPath();ctx.arc(cx+10,cy,10,0,Math.PI*2);ctx.lineWidth=2;ctx.strokeStyle=INK;ctx.stroke();
        if(String(v)===String(ov)&&v!==''){ctx.beginPath();ctx.arc(cx+10,cy,6.5,0,Math.PI*2);ctx.fillStyle=PEN;ctx.fill();ctx.fillStyle=INK;}
        ctx.font=`18px ${FONT}`;ctx.fillText(ol,cx+26,cy);ctx.font=`19px ${FONT}`;}
      cx+=ow[i];});
    return h;}
  if(type==='area'){ctx.font=`20px ${FONT}`;const lines=v?wrap(ctx,v,w-24):[];const h=Math.max(150,46+lines.length*27+14);
    if(!dry){ctx.font=`19px ${FONT}`;ctx.fillText(l,x,y+16);ctx.strokeStyle=INK;ctx.lineWidth=1.5;ctx.strokeRect(x,y+32,w,h-38);ctx.fillStyle=PEN;ctx.font=`bold 20px ${FONT}`;lines.forEach((t,i)=>ctx.fillText(t,x+12,y+54+i*27));ctx.fillStyle=INK;}
    return h;}
  const bw=Math.min(240,Math.max(120,w*0.42));const lab=wrap(ctx,l,w-bw-14);
  ctx.font=`bold 22px ${FONT}`;const vl=(!f.blank&&v!=='')?wrap(ctx,show(k,v),bw-18):[];ctx.font=`19px ${FONT}`;
  const h=Math.max(44,lab.length*24+16,vl.length*27+18);
  if(!dry){lab.forEach((t,i)=>ctx.fillText(t,x,y+h/2-(lab.length-1)*12+i*24));ctx.strokeStyle=INK;ctx.lineWidth=1.5;ctx.strokeRect(x+w-bw,y+4,bw,h-10);
    if(f.blank){ctx.fillStyle='#8a8f96';ctx.font=`italic 15px ${FONT}`;ctx.fillText('paper form only',x+w-bw+10,y+h/2-1);ctx.fillStyle=INK;}
    else if(vl.length){ctx.fillStyle=PEN;ctx.font=`bold 22px ${FONT}`;vl.forEach((t,j)=>ctx.fillText(t,x+w-bw+10,y+h/2-1-(vl.length-1)*13.5+j*27));ctx.fillStyle=INK;}}
  return h;}
const LAYOUT={'Incident':2,'Basic observations':2,'Resuscitation':2,'Aspirin (cardiac-sounding chest pain)':2,'Oxygen':2,'Stroke':1,'Diabetic':1,'Responder actions':2,'History':2,'Safeguarding':2};
function drawSection(ctx,p,title,items,x,y,w,cols,dry){const pad=14,gap=26,colW=(w-pad*2-gap*(cols-1))/cols;
  const head=34;let cy=[y+head+8,y+head+8];const full=items.filter(f=>f[2]==='area'),rest=items.filter(f=>f[2]!=='area');
  const per=Math.ceil(rest.length/cols);
  rest.forEach((f,i)=>{const c=Math.min(cols-1,Math.floor(i/per));const h=drawItem(ctx,p,f,x+pad+c*(colW+gap),cy[c],colW,dry);cy[c]+=h+6;});
  let bottom=Math.max(...cy.slice(0,cols));full.forEach(f=>{bottom+=drawItem(ctx,p,f,x+pad,bottom,w-pad*2,dry)+6;});
  const h=bottom-y+8;
  if(!dry){ctx.fillStyle='#E9EDF2';ctx.fillRect(x,y,w,head);ctx.fillStyle=INK;ctx.font=`bold 20px ${FONT}`;ctx.fillText(title,x+pad,y+head/2);ctx.strokeStyle=INK;ctx.lineWidth=2;ctx.strokeRect(x,y,w,h);}
  return h;}
App.casImage=()=>{const p=App.patient;if(!p)return null;
  const secs=F.map(([t,fs])=>{let items=fs.slice();if(t==='Incident')items.splice(2,0,Object.assign(['ptInit','Patient initials','text'],{blank:true}),Object.assign(['ptDob','Date of birth','text'],{blank:true}));return [t==='History'?'Allergies, medicines, presenting complaint / previous medical history':t,items,LAYOUT[t]||2];});
  const os=obs(p);
  const pass=(ctx,dry)=>{let y=M;
    if(!dry){ctx.fillStyle='#fff';ctx.fillRect(0,0,W,ctx.canvas.height);ctx.fillStyle=INK;ctx.textBaseline='middle';
      ctx.font=`bold 30px ${FONT}`;ctx.fillText('Responder Skills / Equipment Record',M,y+18);ctx.font=`20px ${FONT}`;ctx.fillText('CAS130 v6.2 · South Central Ambulance Service NHS Foundation Trust',M,y+54);
      ctx.textAlign='right';ctx.font=`18px ${FONT}`;ctx.fillText('Completed '+App.dateTime(),W-M,y+18);const n=os.length?Tools.news2(os[os.length-1]):null;if(n&&n.missing.length<7){ctx.font=`bold 20px ${FONT}`;ctx.fillText(`Latest NEWS2: ${n.total} (${App.newsRisk(os[os.length-1])})`,W-M,y+54);}ctx.textAlign='left';}
    y+=84;
    const pairs=[['Stroke','Diabetic']];
    for(let i=0;i<secs.length;i++){const [t,items,cols]=secs[i];
      if(t==='Stroke'){const d=secs[i+1];const hw=(W-M*2-16)/2;const h1=drawSection(ctx,p,t,items,M,y,hw,1,true),h2=drawSection(ctx,p,d[0],d[1],M+hw+16,y,hw,1,true);
        if(!dry){drawSection(ctx,p,t,items,M,y,hw,1,false);drawSection(ctx,p,d[0],d[1],M+hw+16,y,hw,1,false);}y+=Math.max(h1,h2)+14;i++;continue;}
      y+=drawSection(ctx,p,t,items,M,y,W-M*2,cols,dry)+14;}
    if(os.length>1){const rows=os.map(o=>`${App.time(o.t)}  ${App.obsSummary(o)}  ·  NEWS2 ${Tools.news2(o).total}`);ctx.font=`18px ${FONT}`;const lines=rows.flatMap(r=>wrap(ctx,r,W-M*2-28));const h=34+12+lines.length*25+10;
      if(!dry){ctx.fillStyle='#E9EDF2';ctx.fillRect(M,y,W-M*2,34);ctx.fillStyle=INK;ctx.font=`bold 20px ${FONT}`;ctx.fillText('Observation sets',M+14,y+17);ctx.font=`18px ${FONT}`;ctx.fillStyle=PEN;lines.forEach((t,i)=>ctx.fillText(t,M+14,y+34+24+i*25));ctx.fillStyle=INK;ctx.strokeStyle=INK;ctx.lineWidth=2;ctx.strokeRect(M,y,W-M*2,h);}
      y+=h+14;}
    if(!dry){ctx.font=`15px ${FONT}`;ctx.fillStyle='#444';ctx.textAlign='center';ctx.fillText('To maintain patient confidentiality, when possible this form should be handed to a SCAS clinician or immediately sent to the Community Responder Department.',W/2,y+12);
      ctx.fillText('Prepared with the CFR Reference app. Patient initials and date of birth are added on the paper form only.',W/2,y+34);ctx.textAlign='left';}
    return y+56;};
  const probe=document.createElement('canvas');probe.width=W;probe.height=10;const H=pass(probe.getContext('2d'),true);
  const c=document.createElement('canvas');c.width=W;c.height=H;pass(c.getContext('2d'),false);return c;};

/* ---------- sending ---------- */
const OUT='cfr.cas.sendto';
const subject=()=>'CAS130 Responder record '+new Date().toLocaleDateString('en-GB')+(val(App.patient,'incNo').v?' · incident '+val(App.patient,'incNo').v:'');
const fileName=()=>'CAS130_'+new Date().toISOString().slice(0,16).replace(/[-:T]/g,'')+'.png';
const isIOS=/iPhone|iPad|iPod/.test(navigator.userAgent);
async function sendEmail(to,body){const c=App.casImage();const N=window.CFRNative;
  if(N&&N.sendEmail){N.sendEmail(to||'',subject(),body,c?c.toDataURL('image/png').split(',')[1]:'',fileName());return;}
  try{if(c&&navigator.canShare){const blob=await new Promise(r=>c.toBlob(r,'image/png'));const file=new File([blob],fileName(),{type:'image/png'});
      if(navigator.canShare({files:[file]})){await navigator.share({files:[file],title:subject(),text:body});return;}}}catch(e){if(e&&e.name==='AbortError')return;}
  location.href='mailto:'+encodeURIComponent(to||'')+'?subject='+encodeURIComponent(subject())+'&body='+encodeURIComponent(body);}
function sendSms(num,body){const N=window.CFRNative;if(N&&N.sendSms){N.sendSms(num||'',body);return;}
  location.href='sms:'+encodeURIComponent(num||'')+(isIOS?'&':'?')+'body='+encodeURIComponent(body);}

route('/cas130',{title:'CAS130 record',tab:'#/patient',render(){
  if(!App.patient)return `<div class="empty">${I('user')}<h2 class="pt">No patient in progress</h2><p>The CAS130 record fills in from the patient record: obs, SAMPLE, medicines, BE-FAST and the arrest log.</p></div><button class="btn pri block" id="casstart">${I('plus')}Start a new patient</button>`;
  const p=App.patient;p.cas=p.cas||{};const r=responder();const view=App.casView||'form';const so=App.LS.get(OUT,{});
  return `<div id="casform"><h2 class="pt">CAS130 Responder Skills / Equipment Record</h2>
  <div class="cseg mt" role="tablist"><button data-cview="form" aria-pressed="${view==='form'}">${I('list')}Completed form</button><button data-cview="edit" aria-pressed="${view==='edit'}">${I('edit')}Fill in / change</button></div>
  <div class="btnrow mt"><button class="btn" data-jump="casemail">${I('share')}Email</button><button class="btn" data-jump="cassms">${I('mic')}Text</button></div>
  ${view==='form'?`<p class="small muted mt">Filled in from your patient record. Tap the form to zoom. To change anything, use <b>Fill in / change</b>.</p>
    <div class="casimg" id="casimg"><img id="casimgel" alt="Completed CAS130 form"></div>`
  :`<p class="lede mt">Values marked <em class="autotag">auto</em> come from your obs and notes; tap or type to change any of them.</p>
  ${callout('amber','alert','Patient initials and date of birth go on the paper form only: they aren’t kept in the app.')}
  ${F.map(([sec,fs])=>`<h3 class="sh">${esc(sec)}</h3><div class="card stack">${fs.map(f=>fieldHTML(p,f)).join('')}${sec==='Incident'?`<label class="check"><input type="checkbox" id="casremember" ${r.callsign||r.pin?'checked':''}><span class="small">Remember my call sign and PIN (1) on this phone</span></label>`:''}${sec==='Basic observations'&&last(p)?`<div>${App.scoreBox(last(p))}</div>`:''}</div>`).join('')}`}
  <h3 class="sh">Send the completed form</h3>
  <div class="card stack">
    <label class="fld"><span>Email to (optional)</span><input id="casto" type="email" inputmode="email" autocomplete="off" placeholder="Leave blank to choose in your email app" value="${esc(so.email||'')}"></label>
    <label class="check"><input type="checkbox" id="castorem" ${so.email?'checked':''}><span class="small">Remember this email address</span></label>
    <button class="btn pri block" id="casemail">${I('share')}Email the form${window.CFRNative&&window.CFRNative.sendEmail?' (picture attached)':''}</button>
    <label class="fld"><span>Text to mobile number (optional)</span><input id="casnum" type="tel" inputmode="tel" autocomplete="off" placeholder="Leave blank to choose in Messages"></label>
    <button class="btn pri block" id="cassms">${I('mic')}Send as a text message</button>
    <div class="btnrow"><button class="btn" id="casshare">${I('share')}Share…</button><button class="btn" id="cascopy">${I('copy')}Copy text</button></div>
    <details class="mt"><summary class="small">Preview the message text</summary><label class="check mt"><input type="checkbox" id="casblank"><span class="small">Include blank fields</span></label><pre class="ocr" id="castext" style="max-height:340px;margin:8px 0 0;font-family:inherit;font-size:.86rem"></pre></details>
  </div>
  ${callout('amber','alert','This contains patient information. Send it only to addresses and numbers SCAS approves for patient data, then end the job.')}
  <div class="btnrow mt"><button class="btn" id="casreset">${I('trash')}Clear my changes</button><a class="btn" href="#/patient">${I('user')}Patient record</a></div></div>`;},
  after(){
    const st=App.$('#casstart');if(st){st.onclick=()=>{App.pt();App.savePatient();App.render();};return;}
    const p=App.patient,view=App.$('#casform');
    const blank=()=>App.$('#casblank').checked;
    const preview=()=>{App.$('#castext').textContent=App.casText(blank());};
    App.$$('[data-jump]').forEach(b=>b.onclick=()=>{const t=App.$('#'+b.dataset.jump);t.scrollIntoView({behavior:'smooth',block:'center'});const inp=b.dataset.jump==='casemail'?App.$('#casto'):App.$('#casnum');setTimeout(()=>inp.focus(),400);});
    App.$$('[data-cview]').forEach(b=>b.onclick=()=>{App.casView=b.dataset.cview;App.render();});
    const im=App.$('#casimgel');if(im){const c=App.casImage();im.src=c.toDataURL('image/png');App.$('#casimg').onclick=()=>App.$('#casimg').classList.toggle('zoom');}
    const redraw=k=>{const el=App.$(`[data-cf="${k}"]`);if(el){el.outerHTML=fieldHTML(p,FLAT[k]);}preview();};
    const saveResp=()=>{const cb=App.$('#casremember');if(!cb)return;if(!cb.checked){App.LS.del(RESP);return;}App.LS.set(RESP,{callsign:val(p,'callsign').v||'',pin:val(p,'pin1').v||''});};
    view.addEventListener('click',e=>{const b=e.target.closest('[data-cv]');if(!b)return;const k=b.closest('[data-cf]').dataset.cf;const cur=val(p,k).v;
      p.cas[k]=String(cur)===b.dataset.cv?'':b.dataset.cv;App.savePatient();App.native.haptic();redraw(k);});
    view.addEventListener('input',e=>{const i=e.target.closest('[data-ci]');if(!i)return;const k=i.dataset.ci;p.cas[k]=i.value;App.savePatient();
      const tag=i.closest('[data-cf]').querySelector('.autotag');if(tag)tag.remove();if(k==='callsign'||k==='pin1')saveResp();preview();});
    const rm=App.$('#casremember');if(rm)rm.onchange=saveResp;
    const saveTo=()=>{const e=App.$('#casto').value.trim();if(App.$('#castorem').checked&&e)App.LS.set(OUT,{email:e});else App.LS.del(OUT);};
    App.$('#castorem').onchange=saveTo;App.$('#casto').onchange=saveTo;
    App.$('#casblank').onchange=preview;
    App.$('#casemail').onclick=()=>{saveTo();sendEmail(App.$('#casto').value.trim(),App.casText(blank()));};
    App.$('#cassms').onclick=()=>sendSms(App.$('#casnum').value.replace(/[^\d+]/g,''),App.casText(blank()));
    App.$('#casshare').onclick=()=>App.native.share('CAS130 record',App.casText(blank()));
    App.$('#cascopy').onclick=()=>App.copy(App.casText(blank()));
    App.$('#casreset').onclick=()=>App.confirm('Clear the changes you made on this form? Values from your obs and notes stay.','Clear',()=>{p.cas={};App.render();});
    preview();
  }});
})();
